const home = require('./home-controller')
const user = require('./user-controller')

module.exports = {
  home,
  user
}
